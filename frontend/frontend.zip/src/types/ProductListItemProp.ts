import type { Product } from "./Product";


export interface ProductListItemProps {
  product: Product;
}