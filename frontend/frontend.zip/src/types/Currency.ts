export interface Currency {
  label: string;
  symbol: string;
}