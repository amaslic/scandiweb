export interface OrderInput {
  skuList: string[];
}
