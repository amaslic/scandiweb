<?php

declare(strict_types=1);

namespace App\Models\Category;

use App\Database\Database;
use Doctrine\DBAL\Connection;

/**
 * Base abstract class for Category models.
 *
 * Handles generic loading of category data.
 */
abstract class AbstractCategory
{
    protected Connection $connection;
    protected int $id;
    protected string $name;

    public function __construct(int $id)
    {
        $this->connection = Database::getConnection();
        $this->id = $id;
        $this->load();
    }

    abstract protected function load(): void;
    abstract public function getProducts(): array;

    public function getId(): int
    {
        return $this->id;
    }

    public function getName(): string
    {
        return $this->name;
    }
}
