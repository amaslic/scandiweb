<?php

declare(strict_types=1);

namespace App\Models\Product;

use App\Models\Product\AbstractProduct;
use App\Models\Product\SimpleProduct;

use App\Database\Database;
use Doctrine\DBAL\Connection;
use InvalidArgumentException;

/**
 * Factory to instantiate the correct Product subclass based on the product's type.
 */
class ProductFactory
{
    /* protected const TYPE_MAP = [
         'simple'       => SimpleProduct::class,
         'variable'     => VariableProduct::class,
         'configurable' => ConfigurableProduct::class,
     ];

     public static function create(int $id): AbstractProduct
     {
         $connection = Database::getConnection();

         $qb = $connection->createQueryBuilder();
         $row = $qb->select('type')
             ->from('products')
             ->where('id = :id')
             ->setParameter('id', $id)
             ->executeQuery()
             ->fetchAssociative();

         if (!$row || empty($row['type'])) {
             throw new InvalidArgumentException("Product with ID {$id} not found or missing type.");
         }

         $type  = (string) $row['type'];
         $class = self::TYPE_MAP[$type] ?? null;

         if ($class === null) {
             throw new InvalidArgumentException("No product class mapped for type '{$type}'.");
         }

         if (!is_subclass_of($class, AbstractProduct::class)) {
             throw new InvalidArgumentException("Product class '{$class}' is not a valid subclass of AbstractProduct.");
         }

         return new $class($id);
     }*/

    /**
     * Create an AbstractProduct instance for the given product ID.
     *
     * @param int $id
     * @return AbstractProduct
     */
    public static function create(int $id): AbstractProduct
    {
        return new SimpleProduct($id);
    }
}
