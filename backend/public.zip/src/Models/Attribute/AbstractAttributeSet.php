<?php

declare(strict_types=1);

namespace App\Models\Attribute;

use Doctrine\DBAL\Connection;
use App\Database\Database;

/**
 * Base abstract class for attribute sets on products.
 * Loads attribute values for a given product and attribute name.
 */
abstract class AbstractAttributeSet
{
    protected Connection $connection;
    protected int $productId;
    protected string $name;
    protected array $values = [];

    public function __construct(int $productId, string $name)
    {
        $this->connection = Database::getConnection();
        $this->productId = $productId;
        $this->name = $name;
        $this->loadValues();
    }

    /**
     * Load attribute values from the database into $this->values.
     */
    abstract protected function loadValues(): void;

    public function getName(): string
    {
        return $this->name;
    }

    /**
     * Returns the list of values or value objects.
     *
     * @return mixed[]
     */
    public function getValues(): array
    {
        return $this->values;
    }
}
