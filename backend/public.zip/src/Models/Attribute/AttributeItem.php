<?php

declare(strict_types=1);

namespace App\Models\Attribute;

/**
 * Represents a single attribute value/item.
 */
class AttributeItem
{
    protected int $id;
    protected string $value;
    protected ?string $displayValue;

    public function __construct(int $id, string $value, ?string $displayValue)
    {
        $this->id = $id;
        $this->value = $value;
        $this->displayValue = $displayValue;
    }

    public function getId(): int
    {
        return $this->id;
    }

    public function getValue(): string
    {
        return $this->value;
    }

    public function getDisplayValue(): ?string
    {
        return $this->displayValue;
    }
}
