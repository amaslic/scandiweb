<?php

declare(strict_types=1);

namespace App\Models\Price;

use Doctrine\DBAL\FetchMode;

/**
 * Concrete implementation of AbstractPriceCollection.
 */
class PriceCollection extends AbstractPriceCollection
{
    protected function loadPrices(): void
    {
        $qb = $this->connection->createQueryBuilder();
        $rows = $qb->select('amount', 'currency_label', 'currency_symbol')
            ->from('prices')
            ->where('product_id = :pid')
            ->setParameter('pid', $this->productId)
            ->executeQuery()
            ->fetchAllAssociative();

        foreach ($rows as $row) {
            $this->prices[] = new Price(
                (float) $row['amount'],
                (string) $row['currency_label'],
                (string) $row['currency_symbol']
            );
        }
    }
}
