<?php

declare(strict_types=1);

namespace App\Models\Price;

use Doctrine\DBAL\Connection;
use App\Database\Database;

/**
 * Base abstract class for price collections of a product.
 * Loads price entries for a given product.
 */
abstract class AbstractPriceCollection
{
    protected Connection $connection;
    protected int $productId;
    protected array $prices = [];

    public function __construct(int $productId)
    {
        $this->connection = Database::getConnection();
        $this->productId = $productId;
        $this->loadPrices();
    }

    /**
     * Load price entries from the database into $this->prices.
     */
    abstract protected function loadPrices(): void;

    /**
     * Return array of Price objects.
     *
     * @return Price[]
     */
    public function getPrices(): array
    {
        return $this->prices;
    }
}
