<?php

declare(strict_types=1);

namespace App\Models\Price;

/**
 * Represents a single price entry for a product.
 */
class Price
{
    private float $amount;
    private string $currencyLabel;
    private string $currencySymbol;

    public function __construct(float $amount, string $currencyLabel, string $currencySymbol)
    {
        $this->amount = $amount;
        $this->currencyLabel = $currencyLabel;
        $this->currencySymbol = $currencySymbol;
    }

    public function getAmount(): float
    {
        return $this->amount;
    }

    public function getCurrencyLabel(): string
    {
        return $this->currencyLabel;
    }

    public function getCurrencySymbol(): string
    {
        return $this->currencySymbol;
    }
}
