<?php

declare(strict_types=1);

namespace App\GraphQL;

use App\Database\Database;
use App\Models\Category\Category as CategoryModel;
use App\Models\Product\ProductFactory;
use GraphQL\Type\Definition\ObjectType;
use GraphQL\Type\Definition\Type;
use GraphQL\Type\Schema;

class SchemaBuilder
{
    public static function build(): Schema
    {
        $categoryType = null;
        $productType = null;


        $currencyType = new ObjectType([
            'name' => 'Currency',
            'fields' => [
                'label' => Type::nonNull(Type::string()),
                'symbol' => Type::nonNull(Type::string()),
            ],
        ]);


        $priceType = new ObjectType([
            'name' => 'Price',
            'fields' => [
                'amount' => [
                    'type' => Type::nonNull(Type::float()),
                    'resolve' => fn(\App\Models\Price\Price $p) => $p->getAmount(),
                ],
                'currency' => [
                    'type' => Type::nonNull($currencyType),
                    'resolve' => fn(\App\Models\Price\Price $p) => [
                        'label' => $p->getCurrencyLabel(),
                        'symbol' => $p->getCurrencySymbol(),
                    ],
                ],
            ],
        ]);


        // AttributeValue type
        $attributeValueType = new ObjectType([
            'name' => 'AttributeValue',
            'fields' => [
                'value' => Type::nonNull(Type::string()),
                'displayValue' => Type::nonNull(Type::string()),
            ],
        ]);

        // AttributeSet type
        $attributeSetType = new ObjectType([
            'name' => 'AttributeSet',
            'fields' => [
                // expose id (we’ll just reuse the name as the “id”)
                'id' => [
                    'type' => Type::nonNull(Type::string()),
                    'resolve' => fn($attrSet) => $attrSet->getName(),
                ],
                // existing name
                'name' => [
                    'type' => Type::nonNull(Type::string()),
                    'resolve' => fn($attrSet) => $attrSet->getName(),
                ],
                // expose type (text vs swatch)
                'type' => [
                    'type' => Type::nonNull(Type::string()),
                    'resolve' => fn($attrSet) => $attrSet instanceof \App\Models\Attribute\SwatchAttributeSet
                        ? 'swatch'
                        : 'text',
                ],
                'items' => [
                    'type' => Type::listOf($attributeValueType),
                    'resolve' => fn($attrSet) => $attrSet->getValues(),
                ],
            ],
        ]);




        // Product type (fields lazily resolved)
        $productType = new ObjectType([
            'name' => 'Product',
            'fields' => function () use (&$productType, &$categoryType, $priceType, $attributeSetType) {
                return [
                    'id' => [
                        'type' => Type::nonNull(Type::int()),
                        'resolve' => fn($prod) => $prod->getId(),
                    ],
                    'sku' => [
                        'type' => Type::nonNull(Type::string()),
                        'resolve' => fn($prod) => $prod->getSku(),
                    ],
                    'name' => [
                        'type' => Type::nonNull(Type::string()),
                        'resolve' => fn($prod) => $prod->getName(),
                    ],
                    'inStock' => [
                        'type' => Type::nonNull(Type::boolean()),
                        'resolve' => fn($prod) => $prod->isInStock(),
                    ],
                    'gallery' => [
                        'type' => Type::listOf(Type::string()),
                        'resolve' => fn($prod) => $prod->getGallery(),
                    ],
                    'description' => [
                        'type' => Type::string(),
                        'resolve' => fn($prod) => $prod->getDescription(),
                    ],
                    'brand' => [
                        'type' => Type::string(),
                        'resolve' => fn($prod) => $prod->getBrand(),
                    ],
                    'category' => [
                        'type' => $categoryType,
                        'resolve' => fn($prod) => new CategoryModel($prod->getCategoryId()),
                    ],
                    'attributes' => [
                        'type' => Type::listOf($attributeSetType),
                        'resolve' => fn($prod) => $prod->getAttributes(),
                    ],
                    'prices' => [
                        'type' => Type::listOf($priceType),
                        'resolve' => fn($prod) => $prod->getPrices(),
                    ],
                ];
            },
        ]);

        // Category type (fields lazily resolved)
        $categoryType = new ObjectType([
            'name' => 'Category',
            'fields' => function () use (&$categoryType, &$productType) {
                return [
                    'id' => [
                        'type' => Type::nonNull(Type::int()),
                        'resolve' => fn(CategoryModel $cat) => $cat->getId(),
                    ],
                    'name' => [
                        'type' => Type::nonNull(Type::string()),
                        'resolve' => fn(CategoryModel $cat) => $cat->getName(),
                    ],
                    'products' => [
                        'type' => Type::listOf($productType),
                        'resolve' => fn(CategoryModel $cat) => $cat->getProducts(),
                    ],
                ];
            },
        ]);

        // Query type
        $queryType = new ObjectType([
            'name' => 'Query',
            'fields' => [
                'categories' => [
                    'type' => Type::listOf($categoryType),
                    'resolve' => function () {
                        $rows = Database::getConnection()
                            ->createQueryBuilder()
                            ->select('id')
                            ->from('categories')
                            ->executeQuery()
                            ->fetchAllAssociative();

                        return array_map(fn(array $r) => new CategoryModel((int) $r['id']), $rows);
                    },
                ],
                'products' => [
                    'type' => Type::listOf($productType),
                    'args' => [
                        'categoryId' => Type::int(),
                    ],
                    'resolve' => function ($root, array $args) {
                        if (!empty($args['categoryId'])) {
                            return (new CategoryModel($args['categoryId']))->getProducts();
                        }

                        $rows = Database::getConnection()
                            ->createQueryBuilder()
                            ->select('id')
                            ->from('products')
                            ->executeQuery()
                            ->fetchAllAssociative();

                        return array_map(fn(array $r) => ProductFactory::create((int) $r['id']), $rows);
                    },
                ],
                'product' => [
                    'type' => $productType,
                    'args' => ['sku' => Type::nonNull(Type::string())],
                    'resolve' => function ($root, array $args) {
                        $row = Database::getConnection()
                            ->createQueryBuilder()
                            ->select('id')
                            ->from('products')
                            ->where('sku = :sku')
                            ->setParameter('sku', $args['sku'])
                            ->executeQuery()
                            ->fetchAssociative();
                        if (!$row) {
                            return null;
                        }
                        return ProductFactory::create((int) $row['id']);
                    },
                ],
            ],
        ]);

        // Mutation type
        $orderResponseType = new ObjectType([
            'name' => 'OrderResponse',
            'fields' => [
                'success' => Type::nonNull(Type::boolean()),
                'message' => Type::nonNull(Type::string()),
            ],
        ]);

        $mutationType = new ObjectType([
            'name' => 'Mutation',
            'fields' => [
                'createOrder' => [
                    'type' => $orderResponseType,
                    'args' => [
                        'skus' => Type::nonNull(Type::listOf(Type::nonNull(Type::int()))),
                    ],
                    'resolve' => function ($root, array $args) {
                        $total = 0;
                        foreach ($args['skus'] as $id) {
                            $prod = ProductFactory::create($id);
                            $prices = $prod->getPrices();
                            if (!empty($prices)) {
                                $total += $prices[0]->getAmount();
                            }
                        }

                        return [
                            'success' => true,
                            'message' => "Order received. Total calculated: $total",
                        ];
                    },
                ],
            ],
        ]);

        return new Schema([
            'query' => $queryType,
            'mutation' => $mutationType,
        ]);
    }
}
